# FreeETHSpinner

<p>Bot untuk Nuyul Aplikasi Free ETH Spinner</p>

### Cara Install
<pre><code>apt update && apt upgrade
pkg install git
pkg install php
git clone https://github.com/kadal15/FreeETHSpinner.git
cd FreeETHSpinner
pkg install nano
nano config.php
php ETHSpin.php</code></pre>
### Edit Config.php
<p>Isi Dengan Alamat Email Coinbase </p>
<pre><code>&lt;?php
$email = "xxxxxxxxxxxxx@gmail.com";
$deviceid = "xxxxxxxxxx";
?&gt;</code></pre>

### Kunjungi Juga
<p>Blog Jejaka Tutorial : https://jejakatutorial-termux.blogspot.com</p>
<p>Channel Youtube : https://www.youtube.com/channel/UCn5d8Xbp0yt-SWTmxwtayvQ</p>

### Donation
<p>BTC  : 18961sqv9fPuBcEbbi1gHub8ydWePB8yaG</p>
<p>LTC  : LNRkk6o9h1Rh98sDW8byeH9HbeUHwNohDu</p>
<p>ETH  : 0x918af3ccc0012292077891e925668499ee02cdcb</p>
<p>DOGE : DJG4YG3ARUkSt9e5xvHvSS3faVx3v1HM9p</p>
