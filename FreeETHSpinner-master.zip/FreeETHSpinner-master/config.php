<?php

$email = "xxxxxxxxxxx@gmail.com";

$deviceid = "?";

?>
